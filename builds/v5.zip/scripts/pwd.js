function PWD() {
    processor(`Current Directory : ${current_dir}`);
}
