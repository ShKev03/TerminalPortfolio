This a portfolio website with terminal made in JS
